#!/bin/sh

# Deploys are done via `cargo lambda`.

exit 1
